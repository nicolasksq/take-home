// Package members implements the Members resource of the MailChimp API v3.
//
// Reference: http://developer.mailchimp.com/documentation/mailchimp/reference/lists/members/
package members
