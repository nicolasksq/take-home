// Package lists implements the Lists resource of the MailChimp API v3.
//
// Reference: http://developer.mailchimp.com/documentation/mailchimp/reference/lists/
package lists
